The majority of the images the the graphics folder was originally in the folder downloaded https://github.com/clear-code-projects/SimpleZelda/blob/main/start%20setup.zip. I took out some images because they weren't going to be used. But I kept most of the enviornmental images

All cat images were made by me, and the flower pot. I used my ipad to make all the cat pixel art and the flower pot.
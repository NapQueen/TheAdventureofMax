All music in this document is music from freesound.org. The music not listed in this document is the audio that was orginially in the start setup folder downloaded from https://github.com/clear-code-projects/SimpleZelda/blob/main/start%20setup.zip.

credits for audio files from freesound.org:
cat-meowing = https://freesound.org/people/lextrack/sounds/333916/
cat-purr-meow = https://freesound.org/people/LoafDV/sounds/131595/
extracute-cat-meow = https://freesound.org/people/Breviceps/sounds/448084/
maybe-main = https://freesound.org/people/Migfus20/sounds/559832/
nice-cat-meow = https://freesound.org/people/steffcaffrey/sounds/262313/
crate-break = https://freesound.org/people/kevinkace/sounds/66780/
